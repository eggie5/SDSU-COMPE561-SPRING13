WHen you start the app, the 5 tables are shown on 1 form.

They are labeled by name. The first 2 tables are Leagues and Games, they have auto-increment primary keys.

THe other tables, Player games and stats don't have auto increment keys. So you must put in the primatry key by hand before saving.

The toolbars for each table have a lot of buttons but the only ones that work are save, delete and the left right arrows.

WHen you create a Player, you must enter their team id which is the primary key in the team table. Dont fill in the last 
column of the table, it just shows the reference. Same for Games and Stats where it says xxx_id

If any questions, eggie5@gmail.com





